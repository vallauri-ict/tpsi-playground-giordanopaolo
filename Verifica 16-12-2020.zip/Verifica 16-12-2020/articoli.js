let articoli = [
   {nome: "Nikon d19", src: "d19", prezzo: "250", descrizione: "Lorem ipsum 1 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."},
   {nome: "Canon c54  ", src: "c54", prezzo: "300", descrizione: "Lorem ipsum 2 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."},
   {nome: "Sony s72", src: "s72", prezzo: "350", descrizione: "Lorem ipsum 3 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."},
   {nome: "Canon c430", src: "c430", prezzo: "650", descrizione: "Lorem ipsum 16 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."},
   {nome: "Canon c80", src: "c80", prezzo: "250", descrizione: "Lorem ipsum 5 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."},
   {nome: "Sony s84", src: "s84", prezzo: "350", descrizione: "Lorem ipsum 6 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."},
   {nome: "Nikon d90", src: "d90", prezzo: "470", descrizione: "Lorem ipsum 7 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."},
   {nome: "Nikon D100", src: "d100", prezzo: "450", descrizione: "Lorem ipsum 8 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."},
   {nome: "sony s124", src: "s124", prezzo: "500", descrizione: "Lorem ipsum 9 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."},
   {nome: "Canon c137", src: "c137", prezzo: "250", descrizione: "Lorem ipsum 10 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."},  
   {nome: "Nikon D240", src: "d240", prezzo: "550", descrizione: "Lorem ipsum 11 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."},
   {nome: "Canon c280", src: "c280", prezzo: "250", descrizione: "Lorem ipsum 12 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."},    
   {nome: "Canon c300", src: "c300", prezzo: "290", descrizione: "Lorem ipsum 13 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."},   
   {nome: "Sony s314", src: "s314", prezzo: "600", descrizione: "Lorem ipsum 14 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."},
   {nome: "Nikon D330", src: "d330", prezzo: "285", descrizione: "Lorem ipsum 15 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."},	 
   {nome: "Blackmagic", src: "b78", prezzo: "400", descrizione: "Lorem ipsum 4 dolor sit amet, consectetur adipiscing elit. Mauris aliquet aliquam quam sit amet volutpat. Curabitur vel fermentum ipsum."}
]
